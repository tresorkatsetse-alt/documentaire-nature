# Documentaire Nature — génération de l'APK

## Prérequis
- JDK 17
- Android Studio (ou le SDK Android avec la plateforme 35 et les build-tools)

## Méthode 1 : Android Studio (recommandée)
1. File > Open > sélectionner le dossier `apkbuild`.
2. Attendre la synchronisation Gradle (télécharge Gradle 8.9 automatiquement).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK généré : `app/build/outputs/apk/debug/app-debug.apk`.

## Méthode 2 : ligne de commande
1. Créer `local.properties` avec : `sdk.dir=/chemin/vers/Android/Sdk`
2. Avec Gradle 8.9+ installé : `gradle wrapper --gradle-version 8.9` (génère gradlew et gradle-wrapper.jar)
3. `./gradlew assembleDebug`

## APK de publication
Créer un keystore, ajouter un `signingConfig` dans `app/build.gradle`, puis `./gradlew assembleRelease`.
