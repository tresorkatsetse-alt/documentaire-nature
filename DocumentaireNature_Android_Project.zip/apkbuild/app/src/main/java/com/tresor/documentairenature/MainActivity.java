package com.tresor.documentairenature;

import android.app.*;import android.os.*;import android.webkit.*;import android.content.*;import android.net.*;import android.view.*;import android.graphics.Color;import android.widget.Toast;import android.Manifest;import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(244,247,242));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        web=new WebView(this); web.setBackgroundColor(Color.rgb(244,247,242));
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView v,String u){ if(u.startsWith("https://")||u.startsWith("http://")){ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); return true;} return false; }});
        web.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p){ Intent i=p.createIntent(); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); try{startActivityForResult(i,1001);}catch(Exception e){return false;} fileCallback=cb; return true;} });
        web.addJavascriptInterface(new Bridge(),"AndroidBridge"); setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface public void saveVideo(final String url, final String name){
            runOnUiThread(new Runnable(){ public void run(){
                try{
                    if(Build.VERSION.SDK_INT<29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},2001);
                        Toast.makeText(MainActivity.this,"Autorisez le stockage puis r\u00e9essayez",Toast.LENGTH_LONG).show();
                        return;
                    }
                    DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType("video/mp4");
                    r.setTitle(name);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name);
                    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                    Toast.makeText(MainActivity.this,"T\u00e9l\u00e9chargement d\u00e9marr\u00e9 : dossier T\u00e9l\u00e9chargements",Toast.LENGTH_LONG).show();
                }catch(Exception e){
                    Toast.makeText(MainActivity.this,"Erreur : "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }});
        }
    }
    ValueCallback<Uri[]> fileCallback;
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==1001 && fileCallback!=null){ Uri[] u=null; if(c==RESULT_OK&&d!=null){ if(d.getClipData()!=null){int n=d.getClipData().getItemCount();u=new Uri[n];for(int i=0;i<n;i++)u[i]=d.getClipData().getItemAt(i).getUri();}else if(d.getData()!=null)u=new Uri[]{d.getData()};} fileCallback.onReceiveValue(u);fileCallback=null;}}
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
